


<?php



    define('TITLE', 'YouthGBZ');
    define('IMAGE_LOGO',asset('images/logo-pelajar.jpg'));
    define('IMAGE_LOGO_KAP', asset('images/logo-kap.png'));
    define('ROUTE_SONG_NEW', 'song.new');
    define('CATEGORY_PELAJAR', 1);
    define('CATEGORY_KAP', 2);
?>
